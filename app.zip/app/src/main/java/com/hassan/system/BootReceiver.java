package com.hassan.system;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        SharedPreferences prefs = c.getSharedPreferences("hassan_prefs", Context.MODE_PRIVATE);
        boolean enabled = prefs.getBoolean("reminder_enabled", false);
        int hour = prefs.getInt("reminder_hour", -1);
        int minute = prefs.getInt("reminder_minute", 0);
        if (enabled && hour >= 0) {
            ReminderScheduler.schedule(c, hour, minute);
        }
    }
}
