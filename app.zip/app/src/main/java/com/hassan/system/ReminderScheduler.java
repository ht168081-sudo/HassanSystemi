package com.hassan.system;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import java.util.Calendar;

public class ReminderScheduler {
    private static PendingIntent buildPendingIntent(Context c) {
        Intent intent = new Intent(c, ReminderReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(c, 7711, intent, flags);
    }

    public static void schedule(Context c, int hour, int minute) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, 0);
        if (cal.before(Calendar.getInstance())) cal.add(Calendar.DAY_OF_YEAR, 1);

        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            am.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), AlarmManager.INTERVAL_DAY, buildPendingIntent(c));
        }
        SharedPreferences.Editor e = c.getSharedPreferences("hassan_prefs", Context.MODE_PRIVATE).edit();
        e.putBoolean("reminder_enabled", true);
        e.putInt("reminder_hour", hour);
        e.putInt("reminder_minute", minute);
        e.apply();
    }

    public static void cancel(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(buildPendingIntent(c));
        SharedPreferences.Editor e = c.getSharedPreferences("hassan_prefs", Context.MODE_PRIVATE).edit();
        e.putBoolean("reminder_enabled", false);
        e.apply();
    }
}
