package com.hassan.system;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "hassan_system";
    @Override public void onReceive(Context c, Intent intent) {
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(c, CHANNEL_ID) : new android.app.Notification.Builder(c);
        b.setSmallIcon(com.hassan.system.R.drawable.ic_launcher_foreground)
         .setContentTitle("HASSAN SYSTEM")
         .setContentText("حان وقت مهامك اليومية · افتح النظام وابدأ.")
         .setAutoCancel(true);
        Intent openApp = new Intent(c, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        android.app.PendingIntent pi = android.app.PendingIntent.getActivity(c, 0, openApp,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? android.app.PendingIntent.FLAG_IMMUTABLE : 0));
        b.setContentIntent(pi);
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(9911, b.build());
    }
}
