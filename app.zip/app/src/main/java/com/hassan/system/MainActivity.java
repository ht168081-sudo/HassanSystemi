package com.hassan.system;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends android.app.Activity {
    private WebView webView;
    private static final String CHANNEL_ID = "hassan_system";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 21) getWindow().setStatusBarColor(android.graphics.Color.rgb(2,7,17));
        createChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 55);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(this), "Android");
        setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
    }
    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationManager nm=getSystemService(NotificationManager.class); nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID,"HASSAN SYSTEM",NotificationManager.IMPORTANCE_DEFAULT)); } }
    @Override public void onBackPressed(){ if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    public static class AndroidBridge {
        private final Context c; AndroidBridge(Context c){this.c=c;}
        @JavascriptInterface public void notifySystem(String text){
            Vibrator v=(Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE);
            if(v==null||Build.VERSION.SDK_INT<26) return;
            long[] pattern;
            switch(text){
                case "reward": pattern=new long[]{0,35,40,35}; break;
                case "levelup": pattern=new long[]{0,60}; break;
                case "anomaly": pattern=new long[]{0,50,60,50,60,90}; break;
                default: pattern=new long[]{0,25};
            }
            v.vibrate(VibrationEffect.createWaveform(pattern,-1));
        }
        @JavascriptInterface public void hapticPulse(int strength){
            Vibrator v=(Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE); if(v==null || Build.VERSION.SDK_INT<26) return;
            if(strength<=1){ v.vibrate(VibrationEffect.createOneShot(40,VibrationEffect.DEFAULT_AMPLITUDE)); }
            else if(strength==2){ v.vibrate(VibrationEffect.createWaveform(new long[]{0,60,80,60},-1)); }
            else { v.vibrate(VibrationEffect.createWaveform(new long[]{0,70,70,70,70,110},-1)); }
        }
        @JavascriptInterface public void scheduleReminder(int hour, int minute){
            ReminderScheduler.schedule(c, hour, minute);
        }
        @JavascriptInterface public void cancelReminder(){
            ReminderScheduler.cancel(c);
        }
    }
}
